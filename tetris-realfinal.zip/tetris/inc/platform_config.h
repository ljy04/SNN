/* Filename : platform_config.h */

#ifndef __HW_CONFIG_H
#define __HW_CONFIG_H

/* include */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "stm.h"

/* define */

typedef enum { I, O, T, S, Z, J, L } block_type;
typedef enum { left, right } direction;
typedef enum { wait, start, playing, three, two, one } status_type;
typedef enum { win, lose } winlose_type;

typedef unsigned char byte;
typedef unsigned int word;
typedef unsigned int bool;

#define false 0
#define true 1

#define GPIO_KEY             GPIOA
#define GPIO_USART           GPIOA
#define GPIO_DOT             GPIOB
#define GPIO_DOT2            GPIOC
#define GPIO_PIEZO           GPIOC
#define GPIO_USART3          GPIOB

#define GPIO_PIEZO_PIN       GPIO_Pin_3

#define GPIO_LED1_PIN        GPIO_Pin_9 /* RED */
#define GPIO_LED2_PIN        GPIO_Pin_5 /* YELLOW */ 
#define GPIO_LED3_PIN        GPIO_Pin_8 /* BLUE */

#define GPIO_KEY1_PIN        GPIO_Pin_0 /* LEFT_WKUP */
#define GPIO_KEY2_PIN        GPIO_Pin_1 /* RIGHT_USER */
#define GPIO_SPACE_KEY_PIN   GPIO_Pin_13 
#define GPIO_UP_KEY_PIN      GPIO_Pin_4 
#define GPIO_DOWN_KEY_PIN    GPIO_Pin_5 
#define GPIO_LEFT_KEY_PIN    GPIO_Pin_6 
#define GPIO_RIGHT_KEY_PIN   GPIO_Pin_7

#define GPIO_USART_Rx_Pin    GPIO_Pin_10
#define GPIO_USART_Tx_Pin    GPIO_Pin_9

#define GPIO_USART3_Rx_Pin    GPIO_Pin_11
#define GPIO_USART3_Tx_Pin    GPIO_Pin_10

#define GPIO_PORTSOURCE_KEY        GPIO_PortSourceGPIOA

#define GPIO_PINSOURCE_KEY1        GPIO_PinSource0
#define GPIO_PINSOURCE_KEY2        GPIO_PinSource1
#define GPIO_PINSOURCE_KEY3        GPIO_PinSource13
#define GPIO_PINSOURCE_KEY4        GPIO_PinSource4
#define GPIO_PINSOURCE_KEY5        GPIO_PinSource5
#define GPIO_PINSOURCE_KEY6        GPIO_PinSource6
#define GPIO_PINSOURCE_KEY7        GPIO_PinSource7

#define GPIO_EXTI_Line_KEY1        EXTI_Line0
#define GPIO_EXTI_Line_KEY2        EXTI_Line1
#define GPIO_EXTI_Line_KEY3        EXTI_Line13
#define GPIO_EXTI_Line_KEY4        EXTI_Line4
#define GPIO_EXTI_Line_KEY5        EXTI_Line5
#define GPIO_EXTI_Line_KEY6        EXTI_Line6
#define GPIO_EXTI_Line_KEY7        EXTI_Line7

#define GPIO_DOT_COL0_PIN     GPIO_Pin_0
#define GPIO_DOT_COL1_PIN     GPIO_Pin_1
#define GPIO_DOT_COL2_PIN     GPIO_Pin_11
#define GPIO_DOT_COL3_PIN     GPIO_Pin_10
#define GPIO_DOT_COL4_PIN     GPIO_Pin_12
#define GPIO_DOT_COL5_PIN     GPIO_Pin_13
#define GPIO_DOT_COL6_PIN     GPIO_Pin_14
#define GPIO_DOT_COL7_PIN     GPIO_Pin_15

#define GPIO_DOT_ROW0_PIN     GPIO_Pin_6
#define GPIO_DOT_ROW1_PIN     GPIO_Pin_7
#define GPIO_DOT_ROW2_PIN     GPIO_Pin_8
#define GPIO_DOT_ROW3_PIN     GPIO_Pin_9

/* variable */



/* function */

void LED_On_Red (void);
void LED_Off_Red (void);
void LED_On_Yellow (void);
void LED_Off_Yellow (void);
void LED_On_Blue (void);
void LED_Off_Blue (void);
void LED_On_All (void);
void LED_Off_All (void);

void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);
void EXTI_Configuration(void);
void USART1_Init(void);
uint8_t USART_GetCharacter(USART_TypeDef *  usart_p);

void Delay(__IO uint32_t nTime);
void TimingDelay_Decrement(void);

void TIM_ClearITPendingBit(TIM_TypeDef* TIMx, uint16_t TIM_IT);

#endif  /* __HW_CONFIG_H */