/* Filename : segment.c */

/* include */

#include "platform_config.h"

/* define */

/* variable */

/* function */
void INSEG_On_0(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_F_PIN;
}

void INSEG_On_1(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_B_PIN | GPIO_SEG_C_PIN;
}

void INSEG_On_2(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_3(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_4(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_F_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_5(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_F_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_6(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_F_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_7(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_F_PIN;
}

void INSEG_On_8(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_F_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_9(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_F_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_G(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_DP_PIN;
}

void SEG_On_DIG0(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_DIG0_PIN;
}

void SEG_Off_DIG0(void)
{
    GPIO_SEG->BSRR |= GPIO_SEG_DIG0_PIN;
}

void SEG_On_All(void)
{
    GPIO_SEG->BRR |= GPIO_SEG_DIG0_PIN | GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_F_PIN | GPIO_SEG_G_PIN | GPIO_SEG_DP_PIN;
}

void SEG_Off_All(void)
{
    GPIO_SEG->BSRR |= GPIO_SEG_DIG0_PIN | GPIO_SEG_A_PIN | GPIO_SEG_B_PIN | GPIO_SEG_C_PIN | GPIO_SEG_D_PIN | GPIO_SEG_E_PIN | GPIO_SEG_F_PIN | GPIO_SEG_G_PIN | GPIO_SEG_DP_PIN;
}

void INSEG_On_Number(int n)
{
    switch(n)
    {
        case 0 : INSEG_On_0(); break;
        case 1 : INSEG_On_1(); break;
        case 2 : INSEG_On_2(); break;
        case 3 : INSEG_On_3(); break;
        case 4 : INSEG_On_4(); break;
        case 5 : INSEG_On_5(); break;
        case 6 : INSEG_On_6(); break;
        case 7 : INSEG_On_7(); break;
        case 8 : INSEG_On_8(); break;
        case 9 : INSEG_On_9(); break;
        case 10 : INSEG_On_G(); break;
    }
}