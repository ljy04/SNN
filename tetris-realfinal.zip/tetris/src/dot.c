/* Filename : dot.c */

/* include */

#include "platform_config.h"

/* define */

/* variable */

extern word Flag_3ms, Flag_1s;
extern bool display_matrix[16][8];
extern bool current_block[4][4];
extern const int GAME_AREA_WIDTH;
extern const int GAME_AREA_HEIGHT;
extern int block_location_x;
extern int block_location_y; 
word dot_row_position = 0;

/* function */
void COL_On(int n) {
    switch(n)
    {
    case 0  :   GPIO_DOT->BRR |= GPIO_DOT_COL0_PIN;
                break;
    case 1  :   GPIO_DOT->BRR |= GPIO_DOT_COL1_PIN;
                break;
    case 2  :   GPIO_DOT2->BRR |= GPIO_DOT_COL2_PIN;
                break;
    case 3  :   GPIO_DOT2->BRR |= GPIO_DOT_COL3_PIN;
                break;
    case 4  :   GPIO_DOT->BRR |= GPIO_DOT_COL4_PIN;
                break;
    case 5  :   GPIO_DOT->BRR |= GPIO_DOT_COL5_PIN;
                break;
    case 6  :   GPIO_DOT->BRR |= GPIO_DOT_COL6_PIN;
                break;
    case 7  :   GPIO_DOT->BRR |= GPIO_DOT_COL7_PIN;
                break;
    default :   GPIO_DOT->BSRR |= GPIO_DOT_COL0_PIN | GPIO_DOT_COL1_PIN | GPIO_DOT_COL4_PIN | GPIO_DOT_COL5_PIN | GPIO_DOT_COL6_PIN | GPIO_DOT_COL7_PIN;
                GPIO_DOT2->BSRR |=  GPIO_DOT_COL2_PIN | GPIO_DOT_COL3_PIN;
                break;
    }
}

void ROW_On(int n) {
    switch(n) 
    {
    case 1  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 2  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW1_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 3  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 4  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW2_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 5  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW2_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 6  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW3_PIN;
                break;
    case 7  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW3_PIN;
                break;
    case 8  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN;
                break;
    case 9  :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN;
                break;
    case 10 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW2_PIN;
                break;
    case 11 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW2_PIN;
                break;
    case 12 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN;
                break;
    case 13 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW1_PIN;
                break;
    case 14 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN;
                break;
    case 15 :   GPIO_DOT->BSRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                break;
    default :   GPIO_DOT->BRR |= GPIO_DOT_ROW0_PIN | GPIO_DOT_ROW1_PIN | GPIO_DOT_ROW2_PIN | GPIO_DOT_ROW3_PIN;
                break;
    }
}

void Dot_Display(void) {
    int i,j;

    COL_On(8);
    ROW_On(dot_row_position);
    
    for(i = 0; i < GAME_AREA_WIDTH; i++) {
        if(display_matrix[dot_row_position][i]) {
            COL_On(i);
        }
    }
    for(i = 0; i < 4; i++) {
        if(block_location_y + i == dot_row_position) {
            for(j = 0; j < 4; j++) {
                if(current_block[i][j]) {
                    COL_On(block_location_x + j);
                }     
            }
            break;
        }
    }

    dot_row_position++;
    if(dot_row_position >= GAME_AREA_HEIGHT) {
        dot_row_position = 0;
    }
}
