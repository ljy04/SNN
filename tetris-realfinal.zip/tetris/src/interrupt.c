/* Filename : interrupt.c */

/* include */

#include "platform_config.h"

/* define */

#define NVIC_VectTab_RAM             ((uint32_t)0x20000000)
#define NVIC_VectTab_FLASH           ((uint32_t)0x08000000)

#define AIRCR_VECTKEY_MASK    ((uint32_t)0x05FA0000)

/* variable */

extern const int GAME_AREA_WIDTH;
extern const int GAME_AREA_HEIGHT;

extern word Flag_3ms, Count_3ms;
extern word Flag_1000ms, Count_1000ms;
extern word Flag_Button_Delay, Count_Button_Delay;
extern word PIEZO_IO;
word Flag_PIEZO;

extern int block_location_x;
extern int block_location_y; 

extern status_type status;
extern uint8_t getch;
extern bool display_matrix[16][8];
extern bool current_block[4][4];   
extern bool wait_matrix[16][8];
extern bool count1_matrix[16][8];
extern bool count2_matrix[16][8];
extern bool count3_matrix[16][8];
extern bool lose_matrix[16][8];
/* function */

void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset)
{ 
  SCB->VTOR = NVIC_VectTab | (Offset & (uint32_t)0x1FFFFF80);
}

void NVIC_Configuration(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Set the Vector Table base location at 0x08000000 */ 
    NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   

    /* Configure one bit for preemption priority */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    /* Enable the EXTI0 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the EXTI1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable the EXTI4 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable the EXTI4 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable the EXTI9_5 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable the EXTI15_10 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the TIM2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable the TIM3 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI_Configuration(void)
{ 
    EXTI_InitTypeDef EXTI_InitStructure;

    /* Configure gpio as input : Button Left-WKUP */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY1);

    /* Configure EXTI Line to generate an interrupt */
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY1;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /* Configure gpio as input : Button Right-USER */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY2);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY2;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    /* Configure gpio as input : SPACE Key */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY3);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY3;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    /* Configure gpio as input : UP Key */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY4);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY4;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    /* Configure gpio as input : DOWN Key */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY5);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY5;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    /* Configure gpio as input : LEFT Key */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY6);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY6;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    /* Configure gpio as input : RIGHT Key */
    /* Connect EXTI Line to gpio pin */
    GPIO_EXTILineConfig(GPIO_PORTSOURCE_KEY, GPIO_PINSOURCE_KEY7);

    /* Configure EXTI Line to generate an interrupt */  
    EXTI_InitStructure.EXTI_Line    = GPIO_EXTI_Line_KEY7;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    
}

void NVIC_SetPriority(IRQn_Type IRQn, uint32_t priority)
{
  if(IRQn < 0) {
    SCB->SHP[((uint32_t)(IRQn) & 0xF)-4] = ((priority << (8 - __NVIC_PRIO_BITS)) & 0xff); } /* set Priority for Cortex-M3 System Interrupts */
  else {
    NVIC->IP[(uint32_t)(IRQn)] = ((priority << (8 - __NVIC_PRIO_BITS)) & 0xff);    }        /* set Priority for device specific Interrupts      */
}

void NVIC_PriorityGroupConfig(uint32_t NVIC_PriorityGroup)
{
  /* Set the PRIGROUP[10:8] bits according to NVIC_PriorityGroup value */
  SCB->AIRCR = AIRCR_VECTKEY_MASK | NVIC_PriorityGroup;
}

void NVIC_Init(NVIC_InitTypeDef* NVIC_InitStruct)
{
  uint32_t tmppriority = 0x00, tmppre = 0x00, tmpsub = 0x0F;
  
  if (NVIC_InitStruct->NVIC_IRQChannelCmd != DISABLE)
  {
    /* Compute the Corresponding IRQ Priority --------------------------------*/    
    tmppriority = (0x700 - ((SCB->AIRCR) & (uint32_t)0x700))>> 0x08;
    tmppre = (0x4 - tmppriority);
    tmpsub = tmpsub >> tmppriority;

    tmppriority = (uint32_t)NVIC_InitStruct->NVIC_IRQChannelPreemptionPriority << tmppre;
    tmppriority |=  NVIC_InitStruct->NVIC_IRQChannelSubPriority & tmpsub;
    tmppriority = tmppriority << 0x04;
        
    NVIC->IP[NVIC_InitStruct->NVIC_IRQChannel] = tmppriority;
    
    /* Enable the Selected IRQ Channels --------------------------------------*/
    NVIC->ISER[NVIC_InitStruct->NVIC_IRQChannel >> 0x05] =
      (uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
  }
  else
  {
    /* Disable the Selected IRQ Channels -------------------------------------*/
    NVIC->ICER[NVIC_InitStruct->NVIC_IRQChannel >> 0x05] =
      (uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
  }
}

void GPIO_EXTILineConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource)
{
  uint32_t tmp = 0x00;
  
  tmp = ((uint32_t)0x0F) << (0x04 * (GPIO_PinSource & (uint8_t)0x03));
  AFIO->EXTICR[GPIO_PinSource >> 0x02] &= ~tmp;
  AFIO->EXTICR[GPIO_PinSource >> 0x02] |= (((uint32_t)GPIO_PortSource) << (0x04 * (GPIO_PinSource & (uint8_t)0x03)));
}

void EXTI_Init(EXTI_InitTypeDef* EXTI_InitStruct)
{
  uint32_t tmp = 0;

  tmp = (uint32_t)EXTI_BASE;
     
  if (EXTI_InitStruct->EXTI_LineCmd != DISABLE)
  {
    /* Clear EXTI line configuration */
    EXTI->IMR &= ~EXTI_InitStruct->EXTI_Line;
    EXTI->EMR &= ~EXTI_InitStruct->EXTI_Line;
    
    tmp += EXTI_InitStruct->EXTI_Mode;

    *(__IO uint32_t *) tmp |= EXTI_InitStruct->EXTI_Line;

    /* Clear Rising Falling edge configuration */
    EXTI->RTSR &= ~EXTI_InitStruct->EXTI_Line;
    EXTI->FTSR &= ~EXTI_InitStruct->EXTI_Line;
    
    /* Select the trigger for the selected external interrupts */
    if (EXTI_InitStruct->EXTI_Trigger == EXTI_Trigger_Rising_Falling)
    {
      /* Rising Falling edge */
      EXTI->RTSR |= EXTI_InitStruct->EXTI_Line;
      EXTI->FTSR |= EXTI_InitStruct->EXTI_Line;
    }
    else
    {
      tmp = (uint32_t)EXTI_BASE;
      tmp += EXTI_InitStruct->EXTI_Trigger;

      *(__IO uint32_t *) tmp |= EXTI_InitStruct->EXTI_Line;
    }
  }
  else
  {
    tmp += EXTI_InitStruct->EXTI_Mode;

    /* Disable the selected external lines */
    *(__IO uint32_t *) tmp &= ~EXTI_InitStruct->EXTI_Line;
  }
}

ITStatus EXTI_GetITStatus(uint32_t EXTI_Line)
{
  ITStatus bitstatus = RESET;
  uint32_t enablestatus = 0;
  
  enablestatus =  EXTI->IMR & EXTI_Line;
  if (((EXTI->PR & EXTI_Line) != (uint32_t)RESET) && (enablestatus != (uint32_t)RESET))
  {
    bitstatus = SET;
  }
  else
  {
    bitstatus = RESET;
  }
  return bitstatus;
}

void EXTI_ClearITPendingBit(uint32_t EXTI_Line)
{
  EXTI->PR = EXTI_Line;
}

void EXTI0_IRQHandler(void)
{
    int i,j;

    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY1) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY1);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            status = start;
            SerialPutChar3('s');
            for(i = 0; i < GAME_AREA_HEIGHT; i++) {
                for(j = 0; j < GAME_AREA_WIDTH; j++) {
                    display_matrix[i][j] = wait_matrix[i][j];
                }
            }
            for(i = 0; i < 4; i++) {
                for(j = 0; j < 4; j++) {
                    current_block[i][j] = 0;
                }
            }
            //printf("Left-WKUP Button Press\n");
        }
    }
}

void EXTI1_IRQHandler(void)
{
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY2) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY2);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            getch = 's';
        
            //printf("Right-USER Button Press\n");
        }
    }
}

void EXTI4_IRQHandler(void)
{
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY4) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY4);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            rotate_current_block(right);
            if(current_block_is_in_illegal_position()) {
                rotate_current_block(left);
            }
            //printf("UP Button Press\n");
        }
    }
}

void EXTI9_5_IRQHandler(void)
{
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY5) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY5);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            if(status == playing) {
                block_location_y++;
                if(current_block_is_in_illegal_position()) {
                    block_location_y--;
                }
            }
            /*
            if(status == playing) {
                while (!current_block_is_in_illegal_position())
                {
                    block_location_y++;
                }
                block_location_y--;
                solidify_current_block();
                check_for_full_rows();
                drop_block_from_sky();
                // check if the game has ended
                if(current_block_is_in_illegal_position()) {
                    reset_game();
                }
            }
            */
            //printf("DOWN Button Press\n");
        }
    }
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY6) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY6);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            if(status == playing) {
                block_location_x--;
                if(current_block_is_in_illegal_position()) {
                    block_location_x++;
                }
            }
            //printf("LEFT Button Press\n");
        }
    }
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY7) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY7);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            if(status == playing) {
                block_location_x++;
                if(current_block_is_in_illegal_position()) {
                    block_location_x--;
                }
            }
            //printf("RIGHT Button Press\n");
        }
    }
}

void EXTI15_10_IRQHandler(void)
{
    if(EXTI_GetITStatus(GPIO_EXTI_Line_KEY3) != RESET)
    {
        EXTI_ClearITPendingBit(GPIO_EXTI_Line_KEY3);
        if(Flag_Button_Delay) {
            Flag_Button_Delay = 0;
            Count_Button_Delay = 0;
            if(status == playing) {
                while (!current_block_is_in_illegal_position())
                {
                    block_location_y++;
                }
                block_location_y--;
                solidify_current_block();
                check_for_full_rows();
                drop_block_from_sky();
                // check if the game has ended
                if(current_block_is_in_illegal_position()) {
                    reset_game();
                }
            }
            //printf("SPACE Button Press\n");
        }
    }
}

void TIM2_IRQHandler(void)   //TIM2 - 1s
{
    int i,j;
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

    if(status == playing) {
        // move current block down
        block_location_y++;

        // check if black has hit bottom or another piece
        if(current_block_is_in_illegal_position()) {
            block_location_y--;
            solidify_current_block();
            check_for_full_rows();
            drop_block_from_sky();
            // check if the game has ended
            if(current_block_is_in_illegal_position()) {
                reset_game(lose);
            }
        }
    }

    switch(status) {
        case three :    status = two;
                        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
                            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                                display_matrix[i][j] = count2_matrix[i][j];
                            }
                        }
                        break;
        case two   :    status = one;
                        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
                            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                                display_matrix[i][j] = count1_matrix[i][j];
                            }
                        }
                        break;
        case one   :    status = playing;
                        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
                            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                                display_matrix[i][j] = 0;
                            }
                        }
                        drop_block_from_sky();
                        break;
    }
    //printf("TIM2 clock..\n");
}

void TIM3_IRQHandler(void)   //TIM3 - PIEZO 20kHz
{
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    
    if(status == playing)
        tetris_song();

    //printf("TIM3 clock..\n");
}
