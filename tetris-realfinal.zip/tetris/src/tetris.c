/* Filename : tetris.c */

/* include */

#include "platform_config.h"

/* define */

const int GAME_AREA_WIDTH = 8;
const int GAME_AREA_HEIGHT = 16;
extern word Flag_1000ms, Count_1000ms;

/* variable */

bool display_matrix[16][8];
bool ready_matrix[16][8] =    {{0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 1, 1, 1, 1, 1, 0, 0},
                               {0, 1, 1, 1, 1, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 1, 1, 1, 0, 0},
                               {0, 1, 1, 1, 1, 1, 0, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0}};
                           
bool wait_matrix[16][8] =     {{0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {1, 1, 0, 0, 0, 0, 1, 1},
                               {1, 1, 0, 1, 1, 0, 1, 1},
                               {1, 1, 0, 1, 1, 0, 1, 1},
                               {1, 1, 0, 1, 1, 0, 1, 1},
                               {1, 1, 1, 1, 1, 1, 1, 1},
                               {1, 1, 1, 1, 1, 1, 1, 1},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 1, 1, 0, 0, 1, 1, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0}};
                                 
bool main_matrix[16][8] =     {{1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1},
                               {1, 0, 1, 0, 1, 0, 1, 0},
                               {0, 1, 0, 1, 0, 1, 0, 1}};
                           
bool count1_matrix[16][8] =   {{0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0}};
                           
bool count2_matrix[16][8] =   {{0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 1, 1, 0, 1, 0, 0},
                               {0, 0, 0, 0, 0, 1, 0, 0},
                               {0, 0, 0, 0, 1, 1, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 0, 0, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0}};
                           
bool count3_matrix[16][8] =   {{0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 1, 0, 0, 1, 0, 0},
                               {0, 0, 0, 0, 0, 1, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 0, 0, 1, 0, 0},
                               {0, 0, 1, 0, 0, 1, 0, 0},
                               {0, 0, 1, 1, 1, 1, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0}};
                           
bool win_matrix[16][8] =      {{0, 1, 0, 1, 1, 0, 1, 0},
                               {0, 1, 0, 1, 1, 0, 1, 0},
                               {0, 1, 1, 1, 1, 1, 1, 0},
                               {0, 0, 1, 0, 0, 1, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 1, 1, 0, 0, 0, 1, 0},
                               {0, 1, 1, 1, 0, 0, 1, 0},
                               {0, 1, 0, 1, 1, 0, 1, 0},
                               {0, 1, 0, 0, 1, 1, 1, 0},
                               {0, 1, 0, 0, 0, 1, 1, 0}};
                           
bool lose_matrix[16][8] =     {{1, 0, 0, 0, 0, 1, 1, 0},
                               {1, 0, 0, 0, 1, 0, 0, 1},
                               {1, 0, 0, 0, 1, 0, 0, 1},
                               {1, 0, 0, 0, 1, 0, 0, 1},
                               {1, 0, 0, 0, 1, 0, 0, 1},
                               {1, 0, 0, 0, 1, 0, 0, 1},
                               {1, 1, 1, 1, 0, 1, 1, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 0, 0, 0, 0, 0, 0, 0},
                               {0, 1, 1, 0, 1, 1, 1, 1},
                               {1, 0, 0, 1, 1, 0, 0, 0},
                               {1, 0, 0, 0, 1, 0, 0, 0},
                               {0, 1, 1, 0, 1, 1, 1, 1},
                               {0, 0, 0, 1, 1, 0, 0, 0},
                               {1, 0, 0, 1, 1, 0, 0, 0},
                               {0, 1, 1, 0, 1, 1, 1, 1}};

bool block_I [4][4] = {{0, 0, 0, 0},
                       {1, 1, 1, 1},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_O [4][4] = {{0, 1, 1, 0},
                       {0, 1, 1, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_T [4][4] = {{0, 1, 0, 0},
                       {1, 1, 1, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_S [4][4] = {{0, 1, 1, 0},
                       {1, 1, 0, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_Z [4][4] = {{1, 1, 0, 0},
                       {0, 1, 1, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_J [4][4] = {{1, 0, 0, 0},
                       {1, 1, 1, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool block_L [4][4] = {{0, 0, 1, 0},
                       {1, 1, 1, 0},
                       {0, 0, 0, 0},
                       {0, 0, 0, 0}};
bool current_block[4][4];                

block_type current_block_type;
status_type status;
                   
// these two variables give the location of 
// the current block in the game area
int block_location_x;
int block_location_y; 

extern uint8_t getch;
extern word Flag_3ms, Flag_100ms, Flag_333ms, Count_3ms, Count_100ms, Count_333ms;
/* function */
// Sets the block that is given as a parameter as the current block.
void set_current_block(bool b[][4]) {
    int i,j;

    for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
            current_block[i][j] = b[i][j];
        }
    }
}
                   
// Creates a new block and puts up to the top.
void drop_block_from_sky() {
    int r = rand() % 7;
    switch(r) {
        case I:
            set_current_block(block_I);
            current_block_type = I;
            break;
        case O:
            set_current_block(block_O);
            current_block_type = O;
            break;
        case T:
            set_current_block(block_T);
            current_block_type = T;
            break;
        case S:
            set_current_block(block_S);
            current_block_type = S;
            break;
        case Z:
            set_current_block(block_Z);
            current_block_type = Z;
            break;
        case J:
            set_current_block(block_J);
            current_block_type = J;
            break;
        case L:
            set_current_block(block_L);
            current_block_type = L;
            break;
    }
    block_location_x = 2;
    block_location_y = -1;
}

// Rotates current block in direction d, unless it is a square.
void rotate_current_block(direction d) {
    int i,j,k;

    if(current_block_type != O) {
        // transpose matrix
        for(i = 0; i < 3; i++) {
            for(j = i+1; j < 4; j++) {
                bool temp = current_block[i][j];
                current_block[i][j] = current_block[j][i];
                current_block[j][i] = temp;
            }
        }
        // reverse row or column depending on rotation type
        for(i = 0; i < 4; i++) {
            j = 0;
            // set side length of submatrix to reverse
            k = 2;
            if(current_block_type == I) {
                k = 3;
            }
            while(j < k) {
                if(d == right) {
                    bool temp = current_block[i][j];
                    current_block[i][j] = current_block[i][k];
                    current_block[i][k] = temp;
                }
                else {
                    bool temp = current_block[j][i];
                    current_block[j][i] = current_block[k][i];
                    current_block[k][i] = temp;
                }
                j++;
                k--;
            }
        }
    }
}

// Returns true if any part of the current block is out
// of the play area bounds or hits another block.
bool current_block_is_in_illegal_position() {
    int i,j;

    for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
            // part of the block..
            if(current_block[i][j]) {
                // ..is out of game-area
                if(block_location_x + j < 0 ||
                    block_location_x + j >= GAME_AREA_WIDTH ||
                    //block_location_y + i < 0 ||
                    block_location_y + i >= GAME_AREA_HEIGHT) {
                    return true;
                }
                // ..hits an old block
                if(display_matrix[block_location_y + i][block_location_x + j]) {
                    return true;
                }
            }
        }
    }
    return false;
}

// Sets the current block into the play-area making it part of it.
void solidify_current_block() {
    int i,j;

    for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
            if(current_block[i][j]) {
                display_matrix[block_location_y + i][block_location_x + j] = true;
            }
        }
    }
}
    
// Handles full rows by first locating and then deleting them.
void check_for_full_rows() {
    int i,j;
    int full_rows = 0;

    for(i = 1; i < GAME_AREA_HEIGHT; i++) {
        bool row_is_full = true;
        for(j = 0; j < GAME_AREA_WIDTH; j++) {
            if(!display_matrix[i][j]) {
                row_is_full = false;
                break;
            }
        }
        // delete the full row by shifting all rows above by one down
        if(row_is_full) {
            int n = i;
            while(n - 1 >= 2) {
                for(j = 0; j < GAME_AREA_WIDTH; j++) {
                    display_matrix[n][j] = display_matrix[n - 1][j];
                }
                n--;
            }
            full_rows++;
        }
    }

    switch(full_rows)
    {
        case 2  :   SerialPutChar3('1');
                    break;
        case 3  :   SerialPutChar3('2');
                    break;
        case 4  :   SerialPutChar3('3');
                    break;
    }
}

void insert_rows(uint8_t n) {
    int i,j;
    int m;
    int rand8;
    rand8 = rand() % 8;
    switch(n) {
        case '1' : m=1;
                   break;
        case '2' : m=2;
                   break;
        case '3' : m=3;
                   break;
    }

    for(i = m; i < GAME_AREA_HEIGHT; i++) {
        for(j = 0; j < GAME_AREA_WIDTH; j++) {
            display_matrix[i - m][j] = display_matrix[i][j];
        }
    }
    for(i = 0; i < m; i++) {
        for(j = 0; j < GAME_AREA_WIDTH; j++) {
            if(rand8 == j) {
                display_matrix[GAME_AREA_HEIGHT - 1 - i][j] = 0;
            } else {
                display_matrix[GAME_AREA_HEIGHT - 1 - i][j] = 1;
            }
        }
    }
    while(current_block_is_in_illegal_position()) {
        block_location_y--;
    }
}

// Resets and clear the game area.
void reset_game(winlose_type winlose) {
    int i,j;
    status = wait;
    SerialPutChar3('w');
    for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
            current_block[i][j] = 0;
        }
    }
/*
    if(winlose == win) {
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = win_matrix[i][j];
            }
        }
    } else {
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = lose_matrix[i][j];
            }
        }
    }
    //Delay(1000);
*/
    for(i = 0; i < GAME_AREA_HEIGHT; i++) {
        for(j = 0; j < GAME_AREA_WIDTH; j++) {
            display_matrix[i][j] = main_matrix[i][j];
        }
    }
}

void tetris_start() { // 1s
    int i,j;
    
    if(status == wait && getch == 'w') {
        //�ʱ�ȭ��
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = main_matrix[i][j];
            }
        }
        for(i = 0; i < 4; i++) {
            for(j = 0; j < 4; j++) {
                current_block[i][j] = 0;
            }
        }
    } else if(status == start && getch == 'w') {
        //�ڽŷ���
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = wait_matrix[i][j];
            }
        }
        for(i = 0; i < 4; i++) {
            for(j = 0; j < 4; j++) {
                current_block[i][j] = 0;
            }
        }
    } else if(status == wait && getch == 's') {
        //�ڽŷ���
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = ready_matrix[i][j];
            }
        }
        for(i = 0; i < 4; i++) {
            for(j = 0; j < 4; j++) {
                current_block[i][j] = 0;
            }
        }
    } else if(status == start && getch == 's') {
        //���ӽ���
        for(i = 0; i < GAME_AREA_HEIGHT; i++) {
            for(j = 0; j < GAME_AREA_WIDTH; j++) {
                display_matrix[i][j] = count3_matrix[i][j];
            }
        }
        status = three;
        //drop_block_from_sky();
    } else if(status == playing && getch == 'w') {
        reset_game(win);
    }
}