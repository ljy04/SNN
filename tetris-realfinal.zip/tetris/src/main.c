/* Filename : main.c */

/* include */

#include "platform_config.h"

/* define */

/* variable */

uint8_t getch = 'w';
extern status_type status;
extern int block_location_x;
extern int block_location_y; 
extern const int GAME_AREA_WIDTH;
extern const int GAME_AREA_HEIGHT;
extern bool display_matrix[16][8];
extern bool current_block[4][4];   
extern bool main_matrix[16][8];
/* function */

int main(void)
{
    int i,j;
    /* System Clocks Configuration */
    RCC_Configuration();

    RCC->APB2ENR |= RCC_APB2Periph_GPIOA;
    RCC->APB2ENR |= RCC_APB2Periph_GPIOB;
    RCC->APB2ENR |= RCC_APB2Periph_GPIOC;
    RCC->APB2ENR |= RCC_APB2Periph_USART1; 
    RCC->APB1ENR |= RCC_APB1Periph_USART3;
    RCC->APB1ENR |= RCC_APB1Periph_TIM2;
    RCC->APB1ENR |= RCC_APB1Periph_TIM3;

    RCC_GetClocksFreq(&rcc_clocks);
    SysTick_Config(rcc_clocks.SYSCLK_Frequency / 1000); //SYSTICK 1ms

    /* Configure the GPIO ports */
    GPIO_Configuration();

    /* NVIC configuration */
    NVIC_Configuration();

    /* EXTI configuration */
    EXTI_Configuration();

    /* UART initialization */
    USART1_Init();
    USART3_Init();
    /* Timer initialization */
    TIM_Configuration();
    
    for(i = 0; i < GAME_AREA_HEIGHT; i++) {
        for(j = 0; j < GAME_AREA_WIDTH; j++) {
            display_matrix[i][j] = main_matrix[i][j];
        }
    }
    for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
            current_block[i][j] = 0;
        }
    }
    SerialPutChar3('w');
    while(1)
    {
        while(USART_GetFlagStatus(USART3, USART_FLAG_RXNE) == RESET);
        getch = USART_ReceiveData(USART3);
        
        // Test USART1
        USART_SendData(USART1, getch);
        while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);

        
        if(status == playing && (getch == '1' || getch == '2' || getch == '3')) {
            insert_rows(getch);
            getch = 'p';
        }
    }
}