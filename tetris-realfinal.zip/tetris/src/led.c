/* Filename : led.c */

/* include */

#include "platform_config.h"

/* define */

/* variable */

/* function */

void LED_On_Red (void)
{
    GPIO_LED->BRR |= GPIO_LED1_PIN;
}

void LED_Off_Red (void)
{
    GPIO_LED->BSRR |= GPIO_LED1_PIN;
}

void LED_On_Yellow (void)
{
    GPIO_LED->BRR |= GPIO_LED2_PIN;
}

void LED_Off_Yellow (void)
{
    GPIO_LED->BSRR |= GPIO_LED2_PIN;
}

void LED_On_Blue (void)
{
    GPIO_LED->BRR |= GPIO_LED3_PIN;
}

void LED_Off_Blue (void)
{
    GPIO_LED->BSRR |= GPIO_LED3_PIN;
}

void LED_On_All (void)
{
    LED_On_Red();
    LED_On_Yellow();
    LED_On_Blue();
}

void LED_Off_All (void)
{
    LED_Off_Red();
    LED_Off_Yellow();
    LED_Off_Blue();
}
